const activated = {
    /* #Roles */
    roles: true,
    /* /Roles */
    /* #CreateIndividualAtSetup */
    participants: true,
    /* /CreateIndividualAtSetup */
    /* #AssetTracking */
    assets: true,
    /* /AssetTracking */
    /* #StateMachine */
    stateMachine: true,
    /* /StateMachine */
    /* #RecordRegistration */
    records: true,
    /* /RecordRegistration */
}

module.exports = activated;